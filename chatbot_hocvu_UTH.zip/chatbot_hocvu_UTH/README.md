# Chatbot học vụ UTH

## 1. Công dụng

Chatbot học vụ UTH hỗ trợ sinh viên tra cứu các câu hỏi thường gặp về:

- Quy chế đào tạo, đăng ký học phần và học lại.
- Chuyên cần, điều kiện dự thi, điểm số và GPA.
- Cảnh báo học tập, bảo lưu, thôi học và chuyển trường.
- Xét tốt nghiệp và phúc khảo.
- Học phí, phương thức thanh toán và lịch thi.

Chatbot là công cụ hỗ trợ tra cứu và không thay thế thông báo hoặc quy định chính thức của Trường Đại học Giao thông vận tải TP. Hồ Chí Minh. Các thông tin về thời hạn, mức phí hoặc điều kiện áp dụng có thể thay đổi theo khóa và học kỳ. Sinh viên nên kiểm tra lại Portal UTH hoặc liên hệ đơn vị phụ trách.

## 2. Chatbot hoạt động như thế nào?

Khi sinh viên nhập câu hỏi, chatbot thực hiện các bước chính:

1. Chuẩn hóa tiếng Việt: chuyển chữ thường, bỏ dấu, xử lý viết tắt và một số cách gõ phổ biến như `sv`, `hp`, `dkhp`, `tc`.
2. So khớp câu hỏi với bộ dữ liệu gồm **80 FAQ** và **316 câu hỏi biến thể**.
3. Tính mức độ phù hợp bằng chế độ người dùng lựa chọn:
   - **Nhẹ:** kết hợp TF-IDF và Fuzzy Matching, phản hồi nhanh.
   - **Cân bằng:** sử dụng SBERT Semantic để so khớp ngữ nghĩa.
   - **Cao:** kết hợp SBERT với TF-IDF và Fuzzy Matching.
4. Trả về câu trả lời của FAQ phù hợp nếu độ tin cậy đủ cao.
5. Hỏi lại khi câu hỏi chưa rõ, hoặc ghi log khi hệ thống chưa tìm được câu trả lời phù hợp.

Chatbot cũng hỗ trợ một số hội thoại nhiều lượt. Ví dụ, khi hỏi học phí, bot có thể hỏi chương trình đào tạo trước khi trả lời.

Các câu hỏi chưa trả lời tốt và phản hồi của người dùng được lưu để nhóm xem xét, bổ sung dữ liệu. Hệ thống **không tự động huấn luyện lại mô hình** từ log.

## 3. Cấu trúc project

- `app.py`: Giao diện chatbot bằng Streamlit.
- `config.py`: Cấu hình đường dẫn, trọng số và ngưỡng tin cậy.
- `data/faq.json`: Bộ dữ liệu chính gồm 80 FAQ và 316 câu hỏi biến thể.
- `data/FAQ_bien_the_quy_che_dao_tao_UTH_nguon.json`: File nguồn gồm 210 câu biến thể đã được gộp vào dữ liệu chính.
- `chatbot/preprocess.py`: Chuẩn hóa và tiền xử lý tiếng Việt.
- `chatbot/matcher.py`: So khớp TF-IDF, Fuzzy, SBERT và Hybrid.
- `chatbot/semantic.py`: Nạp mô hình SBERT và tính độ tương đồng ngữ nghĩa.
- `chatbot/dialogue.py`: Xử lý ngữ cảnh và hội thoại nhiều lượt.
- `chatbot/logger.py`: Ghi nhận câu hỏi chưa trả lời tốt và phản hồi.
- `evaluate_methods.py`: Đánh giá, so sánh các phương pháp.
- `tests/`: Các bài kiểm thử của project.

## 4. Yêu cầu môi trường

- Windows 10 hoặc Windows 11.
- Khuyến nghị sử dụng **Python 3.12**.
- Kết nối Internet để cài thư viện.
- Khi sử dụng **Cân bằng** hoặc **Cao** lần đầu, hệ thống có thể cần Internet để tải mô hình SBERT.

## 5. Cách chạy chatbot

Giải nén file ZIP, mở thư mục `chatbot_hocvu_UTH`, sau đó mở PowerShell tại thư mục có chứa file `app.py`.

### Bước 1: Tạo môi trường Python

```powershell
py -3.12 -m venv .venv
```

### Bước 2: Cài các thư viện cơ bản

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### Bước 3: Chạy chatbot

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Sau khi chạy thành công, mở trình duyệt tại:

```text
http://localhost:8501
```

Để dừng chatbot, nhấn `Ctrl + C` trong cửa sổ PowerShell đang chạy chương trình.

## 6. Cài thêm SBERT

Chế độ **Nhẹ** có thể sử dụng sau khi cài `requirements.txt`.

Để sử dụng chế độ **Cân bằng** hoặc **Cao**, cài thêm:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-semantic.txt
```

Sau khi cài xong, chạy lại chatbot và chọn mức mong muốn trên giao diện. Lần đầu sử dụng SBERT có thể cần Internet để tải mô hình.

## 7. Kiểm thử và đánh giá

Chạy bộ kiểm thử:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Đánh giá các phương pháp cơ bản:

```powershell
.\.venv\Scripts\python.exe -X utf8 evaluate_methods.py
```

Đánh giá thêm hai phương pháp sử dụng SBERT:

```powershell
.\.venv\Scripts\python.exe -X utf8 evaluate_methods.py --semantic
```

Lệnh có `--semantic` yêu cầu cài thêm `requirements-semantic.txt`. Chương trình in ra kết quả của các phương pháp, trong đó:

- `hybrid_tfidf_fuzzy`: mức **Nhẹ**.
- `semantic`: mức **Cân bằng**.
- `hybrid_semantic`: mức **Cao**.

Tập kiểm thử hiện tại còn nhỏ và có câu trùng với dữ liệu FAQ. Kết quả chỉ dùng để đánh giá ban đầu trên tập kiểm thử của nhóm.