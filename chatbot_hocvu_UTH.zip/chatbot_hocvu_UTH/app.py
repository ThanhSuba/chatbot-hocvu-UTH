"""Giao diện web (Streamlit):  streamlit run app.py"""
from base64 import b64encode
from pathlib import Path

import pandas as pd
import streamlit as st

import config
from chatbot.dialogue import ANSWERED, CLARIFY, Chatbot
from chatbot.matcher import FAQMatcher
from chatbot.logger import STATUS_BAD_FEEDBACK
from chatbot.semantic import SemanticUnavailable

ASSETS = Path(__file__).resolve().parent / "assets"
LOGO = ASSETS / "uth-logo.jpg"

st.set_page_config(page_title="Chatbot học vụ UTH", page_icon=str(LOGO), layout="wide")
st.markdown((ASSETS / "uth.css").read_text(encoding="utf-8"), unsafe_allow_html=True)
logo_data = b64encode(LOGO.read_bytes()).decode("ascii")
st.markdown(
    f"""
    <header class="uth-header">
        <img src="data:image/jpeg;base64,{logo_data}" alt="Logo UTH">
        <div>
            <p class="uth-school">Đại học Giao thông vận tải TP. Hồ Chí Minh</p>
            <h1>Trợ lý học vụ UTH</h1>
            <p>Quy chế đào tạo, học phí và lịch thi</p>
        </div>
    </header>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def get_bot(method: str) -> Chatbot:
    return Chatbot(matcher=FAQMatcher(method=method))

METHOD_LABELS = {
    "Nhẹ (mặc định)": "hybrid_tfidf_fuzzy",
    "Cân bằng": "semantic",
    "Cao": "hybrid_semantic",
}

METHOD_DESCRIPTIONS = {
    "Nhẹ (mặc định)": "TF-IDF + Fuzzy. Phản hồi nhanh, phù hợp dùng hằng ngày.",
    "Cân bằng": "SBERT Semantic. Hiểu được nhiều cách diễn đạt khác nhau.",
    "Cao": "Hybrid SBERT + TF-IDF/Fuzzy. Kết hợp ngữ nghĩa, từ khóa và lỗi gõ.",
}


chat_column, control_column = st.columns([3, 1], gap="large")

with control_column:
    with st.container(border=True):
        st.markdown("#### Mức độ trả lời")
        method_label = st.selectbox("Chọn mức phù hợp", list(METHOD_LABELS), index=0)
        method = METHOD_LABELS[method_label]
        st.caption(METHOD_DESCRIPTIONS[method_label])
        if method in {"semantic", "hybrid_semantic"}:
            st.caption("SBERT tải mô hình ở lần chạy đầu. Khuyến nghị Python 3.12.")

bot = get_bot(method)

if "matcher_method" not in st.session_state:
    st.session_state.matcher_method = method
if st.session_state.matcher_method != method:
    st.session_state.matcher_method = method
    st.session_state.session = bot.new_session()
    st.session_state.messages = []

if "session" not in st.session_state:
    st.session_state.session = bot.new_session()
    st.session_state.messages = []      # [{role, content, meta}]
if "queued" not in st.session_state:
    st.session_state.queued = None

session = st.session_state.session

with control_column:
    with st.container(border=True):
        st.markdown("#### Phiên trò chuyện")
        show_debug = st.toggle("Thông tin kỹ thuật", value=False,
                               help="Hiện FAQ được chọn, điểm so khớp, chủ đề, ngữ cảnh và câu hỏi đã chuẩn hóa.")
        if show_debug:
            st.caption("Dùng khi demo để giải thích vì sao chatbot chọn một câu trả lời.")
        if st.button("↻ Làm mới cuộc trò chuyện", use_container_width=True):
            st.session_state.session = bot.new_session()
            st.session_state.messages = []
            st.session_state.queued = None
            st.rerun()
        st.caption("Làm mới sẽ xóa lịch sử trong phiên hiện tại.")

with chat_column:
    tab_chat, tab_log = st.tabs(["💬 Trò chuyện", "📋 Log câu hỏi chưa trả lời được"])

# ------------------------------------------------------------------ tab chat
with tab_chat:
    if not st.session_state.messages:
        with st.container(border=True):
            st.subheader("Chào bạn, mình có thể hỗ trợ gì?")
            st.write("Chọn một câu hỏi gợi ý hoặc nhập trực tiếp thắc mắc của bạn.")
            examples = [
                "Học phí mỗi tín chỉ bao nhiêu?",
                "Đăng ký học phần khi nào?",
                "Em bị trùng lịch thi thì làm sao?",
                "Rớt môn thì phải làm gì?",
                "Điều kiện bảo lưu là gì?",
                "Cách xem lịch thi cuối kỳ?",
            ]
            suggestion_columns = st.columns(2)
            for index, example in enumerate(examples):
                if suggestion_columns[index % 2].button(example, key=f"suggestion_{index}", use_container_width=True):
                    st.session_state.queued = example
        st.divider()
        with st.chat_message("assistant", avatar=str(LOGO)):
            st.write("Mình sẽ tìm FAQ phù hợp nhất và hỏi lại nếu cần thêm thông tin.")

    for i, m in enumerate(st.session_state.messages):
        with st.chat_message(m["role"], avatar=str(LOGO) if m["role"] == "assistant" else None):
            st.write(m["content"])
            meta = m.get("meta")
            if meta and show_debug:
                st.caption(f"status={meta['status']} · faq={meta['faq_id']} · điểm={meta['score']:.2f} · "
                           f"ngữ cảnh={'có' if meta['ctx'] else 'không'} · chuẩn hóa: {meta['norm']}")
            if meta and meta["status"] == ANSWERED:
                if not m.get("rated") and st.button("👎 Câu trả lời chưa đúng", key=f"bad_{i}"):
                    bot.logger.log(session.id, meta["question"], meta["norm"], STATUS_BAD_FEEDBACK,
                                   meta["score"], meta["faq_id"] or "", "")
                    m["rated"] = True
                    st.toast("Cảm ơn bạn! Mình đã ghi lại để cải thiện.")
                    st.rerun()

    typed = st.chat_input("Nhập câu hỏi về học vụ...")
    prompt = typed or st.session_state.queued
    st.session_state.queued = None
    if prompt:
        try:
            resp = bot.ask(session, prompt)
        except SemanticUnavailable as error:
            st.error(str(error))
            st.stop()
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.session_state.messages.append({
            "role": "assistant", "content": resp.text,
            "meta": {"status": resp.status, "faq_id": resp.faq_id, "score": resp.score,
                     "ctx": resp.used_context, "norm": resp.normalized, "question": prompt},
        })
        st.rerun()

# ------------------------------------------------------------------ tab log
with tab_log:
    rows = bot.logger.read()
    st.write(f"Tổng số lần bot không trả lời được / không chắc chắn: **{len(rows)}**")
    if rows:
        top = bot.logger.summarize(10)
        st.subheader("Câu hỏi lặp lại nhiều nhất")
        st.dataframe(pd.DataFrame(top, columns=["Câu hỏi", "Số lần", "Trạng thái"]),
                     hide_index=True)
        st.subheader("Toàn bộ log")
        df = pd.DataFrame(rows)
        st.dataframe(df, hide_index=True)
        st.download_button("⬇️ Tải log (CSV)", df.to_csv(index=False).encode("utf-8-sig"),
                           file_name="unanswered.csv", mime="text/csv")
    else:
        st.info("Chưa có câu hỏi nào bị ghi log. Hãy thử hỏi một câu ngoài phạm vi, ví dụ: 'Giá vàng hôm nay?'.")
    if st.button("🔄 Tải lại log"):
        st.rerun()
