"""Chạy chatbot trên dòng lệnh:  python chat_cli.py

Lệnh trong lúc chat:  /reset (xóa ngữ cảnh)  /debug (bật/tắt hiện điểm)  /log (xem log)  /thoat
"""
import sys

import config
from chatbot.dialogue import ANSWERED, Chatbot

HELP = "Lệnh: /reset  /debug  /log  /thoat"


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    bot = Chatbot()
    session = bot.new_session()
    debug = False
    print("=== Chatbot hỗ trợ giải đáp thắc mắc học vụ ===")
    print(HELP)
    print("Bot: " + bot._help_text())
    while True:
        try:
            text = input("\nBạn: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nTạm biệt!")
            return 0
        if text in ("/thoat", "/exit", "/quit"):
            print("Bot: Tạm biệt bạn!")
            return 0
        if text == "/reset":
            session.reset()
            print("Bot: Đã xóa ngữ cảnh hội thoại.")
            continue
        if text == "/debug":
            debug = not debug
            print(f"Bot: chế độ debug {'BẬT' if debug else 'TẮT'}.")
            continue
        if text == "/log":
            for q, n, st in bot.logger.summarize(10):
                print(f"  {n}x [{st}] {q}")
            continue
        resp = bot.ask(session, text)
        print("Bot:", resp.text)
        if debug:
            print(f"     [debug] status={resp.status} faq={resp.faq_id} score={resp.score:.2f} "
                  f"ngữ_cảnh={resp.used_context} chuẩn_hóa='{resp.normalized}'")


if __name__ == "__main__":
    sys.exit(main())
