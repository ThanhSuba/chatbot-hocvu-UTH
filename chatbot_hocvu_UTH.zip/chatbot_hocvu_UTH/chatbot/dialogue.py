"""Quản lý hội thoại đa lượt có ngữ cảnh cơ bản.

Ngữ cảnh được lưu trong Session:
  * last_topic    - chủ đề của câu trả lời gần nhất (học phí, lịch thi...)
  * pending       - các gợi ý đang chờ người dùng xác nhận ("1", "đúng rồi", "không phải")

Câu hỏi nối tiếp ("Còn kỳ hè thì sao?", "Hạn nộp là khi nào?") thường thiếu chủ đề.
Bot so khớp lại với điểm của các mục cùng chủ đề lượt trước được khuếch đại (TOPIC_BOOST);
kết quả có ngữ cảnh chỉ được dùng nếu mục đứng đầu thay đổi và điểm cao hơn so khớp độc lập.
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import config
from chatbot.logger import (
    STATUS_LOW_CONFIDENCE, STATUS_OUT_OF_SCOPE, STATUS_REJECTED, UnansweredLogger,
)
from chatbot.matcher import FAQMatcher, Match
from chatbot.preprocess import preprocess, strip_accents

# trạng thái phản hồi
ANSWERED, CLARIFY, FALLBACK, SMALLTALK, EMPTY = "answered", "clarify", "fallback", "smalltalk", "empty"

MAX_INPUT_CHARS = 500


@dataclass
class Response:
    text: str
    status: str
    faq_id: Optional[str] = None
    topic: Optional[str] = None
    score: float = 0.0
    used_context: bool = False
    candidates: List[Match] = field(default_factory=list)
    normalized: str = ""


@dataclass
class Session:
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    history: List[Dict[str, str]] = field(default_factory=list)
    last_topic: Optional[str] = None
    last_faq_id: Optional[str] = None
    last_entities: List[str] = field(default_factory=list)
    pending: List[Match] = field(default_factory=list)

    awaiting_tuition_program: bool = False

    def reset(self) -> None:
        self.awaiting_tuition_program = False
        self.history.clear()
        self.last_topic = self.last_faq_id = None
        self.last_entities = []
        self.pending = []


# ----------------------------------------------------------------- mẫu câu xã giao (so trên chữ không dấu)
_GREET_WORDS = {"xin", "chao", "hello", "hi", "hey", "alo", "ban", "bot", "oi", "ad", "admin"}
_GREET_KEYS = {"chao", "hello", "hi", "hey", "alo"}
_ACK_WORDS = {"ok", "oke", "okay", "uh", "u", "vang", "da", "roi", "hieu", "ro", "nhe", "a", "ah", "duoc"}
_YES_WORDS = {"dung", "phai", "vang", "da", "uh", "u", "ok", "oke", "co", "yes", "y", "roi", "dung roi", "chinh xac"}
_NO_WORDS = {"khong", "sai", "no", "k", "ko", "chua", "khong phai", "khong dung"}
_FOLLOWUP_CUES = re.compile(
    r"^(the con|vay con|con neu|con|vay thi|vay|the thi|the|neu|va|ngoai ra|cai do|cai nay|no |do la|nhu vay|tiep theo)\b"
)
_ORDINALS = {"nhat": 1, "dau": 1, "mot": 1, "hai": 2, "ba": 3}


def _words(text: str) -> List[str]:
    return re.findall(r"\w+", strip_accents(text.lower()))


class Chatbot:
    def __init__(
        self,
        matcher: Optional[FAQMatcher] = None,
        logger: Optional[UnansweredLogger] = None,
        answer_threshold: Optional[float] = None,
        clarify_threshold: float = config.CLARIFY_THRESHOLD,
    ):
        self.matcher = matcher or FAQMatcher()
        self.logger = logger or UnansweredLogger()
        default_threshold = (
            config.SEMANTIC_ANSWER_THRESHOLD
            if self.matcher.method in {"semantic", "hybrid_semantic"}
            else config.ANSWER_THRESHOLD
        )
        self.answer_threshold = default_threshold if answer_threshold is None else answer_threshold
        self.clarify_threshold = clarify_threshold
        with open(config.TOPICS_PATH, encoding="utf-8") as f:
            raw_topics = json.load(f)
        self.topics: Dict[str, Dict[str, str]] = {}
        for key, entry in raw_topics.items():
            info = entry if isinstance(entry, dict) else {"name": entry}
            label = info.get("label") or info.get("name") or key.replace("_", " ")
            self.topics[key] = {**info, "label": label, "terms": info.get("terms") or label}

    # ------------------------------------------------------------------ API chính
    def new_session(self) -> Session:
        return Session()

    def ask(self, session: Session, text: str) -> Response:
        text = (text or "").strip()[:MAX_INPUT_CHARS]
        if not text:
            return self._finish(session, text, Response(
                "Bạn hãy nhập câu hỏi về quy chế đào tạo, lịch thi hoặc học phí nhé.", EMPTY))

        words = _words(text)

        tuition = self._tuition_by_credit(session, words)
        if tuition is not None:
            return self._finish(session, text, tuition)

        shortcut = self._academic_shortcut(session, text, words)
        if shortcut is not None:
            return self._finish(session, text, shortcut)

        # 1) Người dùng đang trả lời một câu hỏi xác nhận của bot
        if session.pending:
            resp = self._handle_pending(session, text, words)
            if resp is not None:
                return self._finish(session, text, resp)

        # 2) So khớp độc lập + (nếu là câu nối tiếp) so khớp có ngữ cảnh
        norm = preprocess(text)
        candidates = self.matcher.search(text, top_k=5)
        top = candidates[0] if candidates else None
        used_context = False

        if session.last_topic and self._looks_like_followup(text, norm, top):
            elliptical = self._is_elliptical(text, norm)
            carry = [e for e in session.last_entities if preprocess(e) not in norm] if elliptical else []
            query = (text + " " + " ".join(carry)).strip()
            ctx = self.matcher.search(query, top_k=5, boost_topic=self._boost_topic(session, norm),
                                      boost=config.TOPIC_BOOST)
            if ctx and (top is None or ctx[0].faq_id != top.faq_id) and ctx[0].score > (top.score if top else 0):
                candidates, top, used_context = ctx, ctx[0], True

        score = top.score if top else 0.0

        # 3) Quyết định
        ambiguous = (
            top is not None and len(candidates) > 1 and not used_context
            and self.clarify_threshold <= score < config.AMBIGUITY_MAX_SCORE
            and score - candidates[1].score < config.AMBIGUITY_MARGIN
        )
        if top and score >= self.answer_threshold and not ambiguous:
            return self._finish(session, text, self._answer(session, top, candidates, used_context, norm))

        smalltalk = self._smalltalk(words)
        if smalltalk:
            return self._finish(session, text, Response(smalltalk, SMALLTALK, normalized=norm))

        if top and (score >= self.clarify_threshold or ambiguous):
            return self._finish(session, text, self._clarify(session, text, norm, candidates))

        return self._finish(session, text, self._fallback(session, text, norm, top))

    def _academic_shortcut(self, session: Session, text: str, words: List[str]) -> Optional[Response]:
        """Xử lý các câu ngắn, đã xuất hiện trong log, nhưng chưa đủ từ để so khớp FAQ."""
        plain = " ".join(words)
        if plain in {"tong quan quy che dao tao", "quy che dao tao la gi"}:
            return Response(
                "Quy chế đào tạo quy định cách đăng ký học phần, đánh giá điểm, học lại, "
                "cảnh báo học tập, bảo lưu và tốt nghiệp. Bạn có thể hỏi cụ thể, ví dụ: "
                "‘mỗi kỳ đăng ký tối đa bao nhiêu tín chỉ?’ hoặc ‘học lại để cải thiện điểm được không?’,",
                ANSWERED,
                topic="tong_quan",
                normalized=preprocess(text),
            )

        if plain in {"hoc lai", "hoc lai la gi"}:
            options = [
                self.matcher.best("Rớt một học phần bắt buộc thì phải làm gì?"),
                self.matcher.best("Sinh viên được học lại học phần vào thời điểm nào?"),
                self.matcher.best("Học lại để cải thiện điểm có được không?"),
            ]
            session.pending = [option for option in options if option is not None]
            return Response(
                "Học lại là đăng ký lại học phần chưa đạt, hoặc học phần đã đạt để cải thiện điểm "
                "theo quy định. Bạn muốn hỏi về:\n"
                "1. Rớt môn bắt buộc thì học lại thế nào?\n"
                "2. Khi nào đăng ký học lại?\n"
                "3. Học lại để cải thiện điểm?\n\n"
                "Bạn trả lời 1, 2, 3 hoặc viết tiếp câu hỏi nhé.",
                CLARIFY,
                topic="hoc_lai_cai_thien",
                candidates=session.pending,
                normalized=preprocess(text),
            )
        return None

    def _tuition_by_credit(self, session: Session, words: List[str]) -> Optional[Response]:
        faq = self.matcher.by_id.get("FAQ_HP_01")
        if faq is None:
            return None
        plain = " ".join(words)
        program = re.search(
            r"\b(chat luong cao|clc|tien tien|cttt|dai tra|he chuan|hoan toan bang tieng anh)\b",
            plain,
        )
        asks_rate = bool(
            re.search(r"\b(hoc phi|don gia|gia|tien|hp)\b", plain)
            and (re.search(r"\b(tin chi|tc)\b", plain) or program)
            and not re.search(r"\b(hoc lai|cai thien|toi da|toi thieu)\b", plain)
        )
        program_reply = (
            session.awaiting_tuition_program
            and (
                plain in {"chuan", "chuong trinh chuan"}
                or re.fullmatch(
                    r"(?:(?:chuong trinh (?:cua )?(?:toi|em|minh) la|(?:toi|em|minh) hoc) )?"
                    r"(?:da )?(?:(?:chuong trinh|he) )?"
                    r"(?:chat luong cao|clc|tien tien|cttt|dai tra|chuan|hoan toan bang tieng anh)(?: a)?",
                    plain.removeprefix("da "),
                )
            )
        )
        session.awaiting_tuition_program = False
        if not (asks_rate or program_reply):
            return None

        session.pending.clear()
        session.last_topic = faq["topic"]
        session.last_faq_id = faq["id"]
        session.last_entities = ["học phí"]
        if program is None and not program_reply:
            session.awaiting_tuition_program = True
            return Response(
                "Bạn đang học chương trình nào?\n\n"
                "- Chương trình đại trà\n"
                "- Chương trình chất lượng cao\n"
                "- Chương trình hoàn toàn bằng tiếng Anh",
                CLARIFY, topic=faq["topic"],
            )

        program_name = program.group() if program else ""
        if program_name in {"he chuan", "dai tra"}:
            answer = (
                "Theo bảng học phí năm học 2026–2027: **hệ chuẩn** có mức 515.000 đồng/tín chỉ "
                "cho khóa 2026, 450.000 đồng/tín chỉ cho khóa 2025 và 400.000 đồng/tín chỉ "
                "cho khóa 2024 trở về trước. Bạn vẫn nên kiểm tra khoản phải đóng của cá nhân tại "
                "[Portal UTH](https://portal.ut.edu.vn/) → **Tra cứu công nợ** → **chọn học kỳ**."
            )
        elif program_name in {"chat luong cao", "clc", "tien tien", "cttt"}:
            answer = (
                "Theo bảng học phí năm học 2026–2027: **chương trình tiên tiến/chất lượng cao** "
                "có mức 1.120.000 đồng/tín chỉ cho khóa 2026. Mức áp dụng cho khóa 2024–2025 là "
                "980.000 đồng/tín chỉ. Kiểm tra công nợ trên [Portal UTH](https://portal.ut.edu.vn/) "
                "để xem số tiền phải đóng theo học phần và học kỳ của bạn."
            )
        elif program_name == "hoan toan bang tieng anh":
            answer = (
                "Theo bảng học phí năm học 2026–2027 của chương trình hoàn toàn bằng tiếng Anh: "
                "học phần giảng dạy bằng tiếng Việt là 980.000 đồng/tín chỉ và học phần giảng dạy "
                "bằng tiếng Anh là 1.500.000 đồng/tín chỉ. Bạn kiểm tra công nợ trên "
                "[Portal UTH](https://portal.ut.edu.vn/) để biết khoản áp dụng cho học kỳ của mình."
            )
        else:
            answer = faq["answer"]
        return Response(answer, ANSWERED, faq["id"], faq["topic"], used_context=bool(program_reply))

    # ------------------------------------------------------------------ các nhánh trả lời
    def _answer(self, session: Session, top: Match, candidates: List[Match],
                used_context: bool, norm: str) -> Response:
        session.last_topic, session.last_faq_id, session.pending = top.topic, top.faq_id, []
        seen = norm + " " + preprocess(top.question)
        session.last_entities = [e for e in config.ENTITY_PHRASES if preprocess(e) in seen]
        related = [
            c for c in candidates[1:]
            if c.score >= config.SUGGEST_THRESHOLD and top.score - c.score <= config.SUGGEST_MARGIN
        ][:2]
        text = top.answer
        if top.faq_id == "FAQ_HP_01":
            text = (
                "Để xem học phí từng học phần, đăng nhập [Portal UTH](https://portal.ut.edu.vn/), "
                "mở **Tra cứu công nợ** và chọn học kỳ. "
                "Nếu bạn muốn biết đơn giá một tín chỉ, hãy cho mình biết chương trình bạn đang học."
            )
            session.awaiting_tuition_program = True
        if related:
            text += "\n\nCó thể bạn cũng muốn hỏi:\n" + "\n".join(f"• {c.question}" for c in related)
        return Response(text, ANSWERED, top.faq_id, top.topic, top.score, used_context, candidates, norm)

    def _clarify(self, session: Session, text: str, norm: str, candidates: List[Match]) -> Response:
        options = candidates[: config.MAX_SUGGESTIONS]
        session.pending = options
        lines = [f"{i}. {c.question}" for i, c in enumerate(options, 1)]
        msg = ("Mình chưa chắc mình hiểu đúng ý bạn. Có phải bạn muốn hỏi:\n"
               + "\n".join(lines)
               + "\n\nBạn trả lời số thứ tự (1, 2, 3...) hoặc diễn đạt lại câu hỏi giúp mình nhé.")
        self.logger.log(session.id, text, norm, STATUS_LOW_CONFIDENCE, options[0].score,
                        options[0].faq_id, session.last_topic or "")
        return Response(msg, CLARIFY, options[0].faq_id, options[0].topic, options[0].score,
                        candidates=candidates, normalized=norm)

    def _fallback(self, session: Session, text: str, norm: str, top: Optional[Match]) -> Response:
        msg = ("Xin lỗi, mình chưa có thông tin về câu hỏi này. Mình đã ghi lại để nhà trường bổ sung. "
               "Bạn có thể hỏi về: " + self._topic_list() + ".")
        self.logger.log(session.id, text, norm, STATUS_OUT_OF_SCOPE, top.score if top else 0.0,
                        top.faq_id if top else "", session.last_topic or "")
        return Response(msg, FALLBACK, None, None, top.score if top else 0.0, normalized=norm)

    # ------------------------------------------------------------------ xử lý lượt nối tiếp
    def _handle_pending(self, session: Session, text: str, words: List[str]) -> Optional[Response]:
        options = session.pending
        wset = set(words)
        choice: Optional[int] = None
        for w in words:
            if w.isdigit() and 1 <= int(w) <= len(options):
                choice = int(w)
                break
            if w in _ORDINALS and len(words) <= 4 and _ORDINALS[w] <= len(options):
                choice = _ORDINALS[w]
                break
        if choice is None and len(words) <= 3 and wset & _YES_WORDS and not wset & _NO_WORDS:
            choice = 1
        if choice is not None:
            picked = options[choice - 1]
            norm = preprocess(text)
            return self._answer(session, picked, options, False, norm)

        if len(words) <= 3 and wset & _NO_WORDS:
            top = options[0]
            session.pending = []
            self.logger.log(session.id, f"(từ chối gợi ý) {top.question}", preprocess(top.question),
                            STATUS_REJECTED, top.score, top.faq_id, session.last_topic or "")
            return Response("Mình hiểu rồi. Bạn thử diễn đạt lại câu hỏi bằng từ khóa khác "
                            "(ví dụ: học phí, lịch thi, bảo lưu...) giúp mình nhé.", CLARIFY, normalized="")
        session.pending = []   # người dùng hỏi câu mới -> bỏ gợi ý cũ
        return None

    def _boost_topic(self, session: Session, norm: str) -> Optional[str]:
        """Chủ đề được khuếch đại điểm: mặc định là chủ đề lượt trước, nhưng nếu câu hỏi nêu rõ
        một chủ đề khác (vd: 'Còn học phí thì sao?') thì chuyển sang chủ đề đó."""
        padded = f" {norm} "
        for key, info in self.topics.items():
            term = preprocess(info.get("terms", ""))
            if term and key != session.last_topic and f" {term} " in padded:
                return key
        return session.last_topic

    def _is_elliptical(self, text: str, norm: str) -> bool:
        """Câu khuyết chủ đề: bắt đầu bằng từ nối (còn/thế/vậy/nếu...) hoặc rất ngắn."""
        return bool(_FOLLOWUP_CUES.match(" ".join(_words(text)))) or len(norm.split()) <= config.FOLLOWUP_MAX_TOKENS

    def _looks_like_followup(self, text: str, norm: str, top: Optional[Match]) -> bool:
        if self._is_elliptical(text, norm):
            return True
        return top is None or top.score < self.answer_threshold

    # ------------------------------------------------------------------ xã giao
    def _smalltalk(self, words: List[str]) -> Optional[str]:
        if not words or len(words) > 8:
            return None
        wset, joined = set(words), " ".join(words)
        if wset <= _GREET_WORDS and wset & _GREET_KEYS:
            return "Xin chào! Mình là chatbot hỗ trợ giải đáp thắc mắc học vụ. " + self._help_text()
        if "cam on" in joined or "thanks" in wset or "thank" in wset or "cảm" in wset:
            return "Rất vui được giúp bạn! Nếu còn thắc mắc về học vụ, cứ hỏi mình nhé."
        if wset & {"bye", "tam"} and ("bye" in wset or "tam biet" in joined) or "hen gap lai" in joined:
            return "Tạm biệt bạn! Chúc bạn học tốt."
        if joined in {"ban la ai", "ban ten gi", "ban lam duoc gi", "ban giup duoc gi", "giup duoc gi",
                      "huong dan", "help", "tro giup", "ban co the lam gi"}:
            return self._help_text()
        if wset <= _ACK_WORDS:
            return "Bạn cần mình hỗ trợ thêm điều gì không?"
        return None

    def _topic_list(self) -> str:
        return ", ".join(t["label"].lower() for k, t in self.topics.items() if k != "khac")

    def _help_text(self) -> str:
        return ("Mình có thể trả lời các câu hỏi về: " + self._topic_list()
                + ".\n\nBạn có thể hỏi nhiều lượt liên tiếp, ví dụ:\n"
                + "• Học phí mỗi tín chỉ bao nhiêu?\n"
                + "• Còn kỳ hè thì sao?")

    # ------------------------------------------------------------------ ghi lịch sử
    def _finish(self, session: Session, text: str, resp: Response) -> Response:
        session.history.append({"user": text, "bot": resp.text, "status": resp.status,
                                "faq_id": resp.faq_id or ""})
        if len(session.history) > config.MAX_HISTORY:
            del session.history[: len(session.history) - config.MAX_HISTORY]
        return resp
