"""Ghi log các câu hỏi chatbot không trả lời được (để người soạn FAQ bổ sung sau)."""
from __future__ import annotations

import csv
import threading
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import config

# Trạng thái ghi log
STATUS_OUT_OF_SCOPE = "ngoai_pham_vi"        # điểm quá thấp, bot không có thông tin
STATUS_LOW_CONFIDENCE = "khong_chac_chan"    # bot chỉ gợi ý, chưa dám trả lời
STATUS_REJECTED = "tu_choi_goi_y"            # người dùng nói gợi ý không đúng
STATUS_BAD_FEEDBACK = "danh_gia_sai"         # người dùng bấm "câu trả lời chưa đúng"

FIELDS = [
    "thoi_gian", "session_id", "cau_hoi", "cau_hoi_chuan_hoa",
    "trang_thai", "diem", "faq_gan_nhat", "chu_de_ngu_canh",
]


class UnansweredLogger:
    def __init__(self, path: Path | str = config.UNANSWERED_LOG_PATH):
        self.path = Path(path)
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists() or self.path.stat().st_size == 0:
            # utf-8-sig để Excel mở file CSV tiếng Việt không bị lỗi font
            with open(self.path, "w", newline="", encoding="utf-8-sig") as f:
                csv.DictWriter(f, fieldnames=FIELDS).writeheader()

    def log(
        self, session_id: str, question: str, normalized: str, status: str,
        score: float, nearest_faq: str = "", context_topic: str = "",
    ) -> None:
        row = {
            "thoi_gian": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "session_id": session_id,
            "cau_hoi": question.strip(),
            "cau_hoi_chuan_hoa": normalized,
            "trang_thai": status,
            "diem": f"{score:.3f}",
            "faq_gan_nhat": nearest_faq,
            "chu_de_ngu_canh": context_topic or "",
        }
        with self._lock, open(self.path, "a", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=FIELDS).writerow(row)

    def read(self) -> List[Dict[str, str]]:
        if not self.path.exists():
            return []
        with open(self.path, newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))

    def summarize(self, top_n: int = 10) -> List[Tuple[str, int, str]]:
        """Gom các câu hỏi giống nhau (theo dạng chuẩn hóa): [(câu mẫu, số lần, trạng thái phổ biến)]."""
        groups: Dict[str, List[Dict[str, str]]] = defaultdict(list)
        for row in self.read():
            groups[row["cau_hoi_chuan_hoa"] or row["cau_hoi"]].append(row)
        ranked = sorted(groups.values(), key=len, reverse=True)[:top_n]
        out = []
        for rows in ranked:
            status = Counter(r["trang_thai"] for r in rows).most_common(1)[0][0]
            out.append((rows[0]["cau_hoi"], len(rows), status))
        return out

    def clear(self) -> None:
        with self._lock, open(self.path, "w", newline="", encoding="utf-8-sig") as f:
            csv.DictWriter(f, fieldnames=FIELDS).writeheader()
