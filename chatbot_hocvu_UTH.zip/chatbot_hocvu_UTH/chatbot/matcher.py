"""So khớp câu hỏi với FAQ bằng độ tương đồng (không chỉ so khớp từ khóa chính xác).

Điểm cuối cùng của một cặp (câu hỏi người dùng, câu hỏi mẫu trong FAQ) là tổ hợp:
  * TF-IDF cosine theo từ (1-2 từ)         -> bắt cụm từ đúng nghĩa
  * TF-IDF cosine theo n-gram ký tự        -> chịu lỗi chính tả / thiếu dấu / gõ tắt
  * Fuzzy matching (rapidfuzz)             -> chịu thứ tự từ khác nhau, từ thừa/thiếu
rồi nhân với hệ số "độ phủ từ vựng" để câu hỏi chứa nhiều từ lạ (ngoài phạm vi) bị hạ điểm.

Mỗi mục FAQ có nhiều cách hỏi (variants); điểm của mục = điểm cao nhất trong các cách hỏi.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
from rapidfuzz import fuzz, process
from sklearn.feature_extraction.text import TfidfVectorizer

import config
from chatbot.preprocess import preprocess


# Từ nghi vấn / từ chung chung: trùng nhau ở những từ này không chứng minh cùng chủ đề
# (vd: "Bạn bao nhiêu tuổi?" không liên quan "Học phí bao nhiêu?")
GENERIC_TOKENS = {
    "bao", "nhieu", "khi", "nao", "nhu", "the", "sao", "khong", "duoc", "gi", "lam",
    "o", "dau", "co", "may", "bi", "hoi",
}
NO_CONTENT_PENALTY = 0.5


@dataclass
class Match:
    faq_id: str
    topic: str
    question: str
    answer: str
    score: float
    tfidf_word: float = 0.0
    tfidf_char: float = 0.0
    fuzzy: float = 0.0
    semantic: float = 0.0
    matched_variant: str = ""


class FAQMatcher:
    def __init__(
        self,
        faq_path: Path | str = config.FAQ_PATH,
        w_word: float = config.W_TFIDF_WORD,
        w_char: float = config.W_TFIDF_CHAR,
        w_fuzzy: float = config.W_FUZZY,
        method: str = "hybrid_tfidf_fuzzy",
    ):
        self.w_word, self.w_char, self.w_fuzzy = w_word, w_char, w_fuzzy
        self.method = method
        self._semantic_engine = None
        with open(faq_path, encoding="utf-8") as f:
            self.faqs: List[dict] = json.load(f)
        self.by_id: Dict[str, dict] = {f["id"]: f for f in self.faqs}

        # Mỗi "tài liệu" = một cách hỏi (câu hỏi chuẩn + các variants) của một mục FAQ
        self._doc_faq: List[int] = []
        self._doc_raw: List[str] = []
        self._doc_norm: List[str] = []
        for idx, faq in enumerate(self.faqs):
            for text in [faq["question"], *faq.get("variants", [])]:
                self._doc_faq.append(idx)
                self._doc_raw.append(text)
                self._doc_norm.append(preprocess(text))

        self._word_vec = TfidfVectorizer(
            tokenizer=str.split, token_pattern=None, lowercase=False,
            ngram_range=(1, 2), sublinear_tf=True,
        )
        self._char_vec = TfidfVectorizer(
            analyzer="char_wb", ngram_range=(2, 4), sublinear_tf=True, lowercase=False,
        )
        self._X_word = self._word_vec.fit_transform(self._doc_norm)
        self._X_char = self._char_vec.fit_transform(self._doc_norm)

        self.vocab = sorted({t for d in self._doc_norm for t in d.split()})
        self._vocab_set = set(self.vocab)
        self._doc_faq_arr = np.array(self._doc_faq)

    # ------------------------------------------------------------------ tiện ích
    def correct_typos(self, norm_query: str) -> str:
        """Sửa lỗi chính tả nhẹ: từ không có trong từ vựng FAQ -> từ gần nhất (nếu đủ giống)."""
        out = []
        for tok in norm_query.split():
            if tok in self._vocab_set or tok.isdigit() or len(tok) < 5:
                out.append(tok)
                continue
            best = process.extractOne(tok, self.vocab, scorer=fuzz.ratio, score_cutoff=84)
            out.append(best[0] if best else tok)
        return " ".join(out)

    def coverage(self, norm_query: str) -> float:
        toks = norm_query.split()
        if not toks:
            return 0.0
        return sum(t in self._vocab_set for t in toks) / len(toks)

    # ------------------------------------------------------------------ tìm kiếm
    def search(self, query: str, top_k: int = 5, boost_topic: Optional[str] = None,
               boost: float = 0.0) -> List[Match]:
        """Trả về tối đa top_k mục FAQ (mỗi mục một lần) xếp theo điểm giảm dần.

        boost_topic / boost: dùng cho câu hỏi nối tiếp - nhân điểm các mục thuộc chủ đề của
        lượt trước với (1 + boost). Chỉ khuếch đại bằng chứng sẵn có, không tạo điểm từ hư không.
        """
        norm = self.correct_typos(preprocess(query))
        if not norm:
            return []

        qw = self._word_vec.transform([norm])
        qc = self._char_vec.transform([norm])
        cos_word = (self._X_word @ qw.T).toarray().ravel()
        cos_char = (self._X_char @ qc.T).toarray().ravel()

        fuzzy = np.array([
            0.5 * fuzz.token_set_ratio(norm, d) + 0.5 * fuzz.token_sort_ratio(norm, d)
            for d in self._doc_norm
        ]) / 100.0

        semantic = np.zeros_like(fuzzy)
        if self.method in {"semantic", "hybrid_semantic"}:
            if self._semantic_engine is None:
                from chatbot.semantic import SemanticEngine
                self._semantic_engine = SemanticEngine(self._doc_raw)
            semantic = self._semantic_engine.scores(query)

        if self.method == "tfidf":
            base = 0.62 * cos_word + 0.38 * cos_char
        elif self.method == "fuzzy":
            base = fuzzy
        elif self.method == "semantic":
            base = semantic
        elif self.method == "hybrid_semantic":
            # Kết hợp lexical + semantic: semantic giữ vai trò chính, lexical giúp câu mã/viết tắt.
            lexical = self.w_word * cos_word + self.w_char * cos_char + self.w_fuzzy * fuzzy
            base = 0.55 * semantic + 0.45 * lexical
        else:
            base = self.w_word * cos_word + self.w_char * cos_char + self.w_fuzzy * fuzzy

        # Semantic đã có khả năng khái quát từ vựng; coverage chỉ áp dụng cho lexical.
        score = base if self.method == "semantic" else base * (0.55 + 0.45 * self.coverage(norm))
        # phạt các cách hỏi mà câu hỏi chỉ trùng ở từ chung chung, không trùng từ nội dung nào
        content = {t for t in norm.split() if t not in GENERIC_TOKENS}
        if content:
            shares = np.array([bool(content & set(d.split())) for d in self._doc_norm])
            score = np.where(shares, score, score * NO_CONTENT_PENALTY)
        if boost_topic and boost:
            in_topic = np.array([self.faqs[i]["topic"] == boost_topic for i in self._doc_faq])
            score = np.where(in_topic, np.minimum(score * (1.0 + boost), 1.0), score)

        best_per_faq: Dict[int, int] = {}
        for doc_i, faq_i in enumerate(self._doc_faq):
            cur = best_per_faq.get(faq_i)
            if cur is None or score[doc_i] > score[cur]:
                best_per_faq[faq_i] = doc_i

        ranked = sorted(best_per_faq.values(), key=lambda i: score[i], reverse=True)[:top_k]
        results = []
        for i in ranked:
            faq = self.faqs[self._doc_faq[i]]
            results.append(Match(
                faq_id=faq["id"], topic=faq["topic"], question=faq["question"],
                answer=faq["answer"], score=float(score[i]),
                tfidf_word=float(cos_word[i]), tfidf_char=float(cos_char[i]),
                fuzzy=float(fuzzy[i]), semantic=float(semantic[i]), matched_variant=self._doc_raw[i],
            ))
        return results

    def best(self, query: str) -> Optional[Match]:
        res = self.search(query, top_k=1)
        return res[0] if res else None
