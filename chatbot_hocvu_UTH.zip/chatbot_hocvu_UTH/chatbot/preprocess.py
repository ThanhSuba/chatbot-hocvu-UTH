"""Tiền xử lý văn bản tiếng Việt cho chatbot học vụ.

Các bước (theo thứ tự):
 1. Chuẩn hóa Unicode (NFC), chữ thường.
 2. Tách từ, mở rộng viết tắt / teencode (đkhp, hp, sv, ko, dc...).
 3. Bỏ từ dừng (chỉ những từ không làm mất nghĩa).
 4. Bỏ dấu tiếng Việt  -> câu hỏi gõ không dấu và có dấu cho cùng kết quả.
 5. Chuẩn hóa cụm từ đồng nghĩa (môn học -> học phần, đóng tiền -> nộp học phí...).

Cả câu hỏi người dùng lẫn dữ liệu FAQ đều đi qua cùng một pipeline nên luôn nhất quán.
"""
from __future__ import annotations

import re
import unicodedata
from typing import List

# ---------------------------------------------------------------- viết tắt / teencode
# key: token (đã lower, có hoặc không dấu) -> cụm thay thế (có dấu)
ABBREVIATIONS = {
    "hp": "học phí",
    "đkhp": "đăng ký học phần",
    "dkhp": "đăng ký học phần",
    "hk": "học kỳ",
    "sv": "sinh viên",
    "gv": "giảng viên",
    "tc": "tín chỉ",
    "tn": "tốt nghiệp",
    "gpa": "điểm trung bình tích lũy",
    "cpa": "điểm trung bình tích lũy",
    "đtb": "điểm trung bình",
    "dtb": "điểm trung bình",
    "đk": "điều kiện",
    "ko": "không", "k": "không", "hok": "không", "hông": "không", "khong": "không",
    "kg": "không", "hem": "không",
    "dc": "được", "đc": "được", "dk": "được",
    "j": "gì", "ntn": "như thế nào", "bn": "bao nhiêu", "bnh": "bao nhiêu",
    "vs": "với", "r": "rồi", "z": "vậy", "wa": "quá", "tg": "thời gian",
    "pdt": "phòng đào tạo", "cntt": "công nghệ thông tin",
    "kì": "kỳ", "kỳ": "kỳ",
}

# Từ dừng CÓ DẤU: chỉ xóa khi người dùng gõ có dấu (vì "thi" không dấu là "thi cử").
STOPWORDS_ACCENTED = {
    "thì", "là", "của", "và", "mà", "nhé", "nhỉ", "nha", "nhá", "ạ", "ơi", "ừ",
    "cho", "tôi", "em", "mình", "tui", "bạn", "xin", "hỏi", "vậy", "này", "đó",
    "cái", "những", "về", "giúp", "với", "ạ", "à", "ơi", "các", "một",
    "rồi", "nữa", "hả", "hở", "luôn", "giờ", "bây",
}
# Từ dừng KHÔNG DẤU an toàn (không trùng từ có nghĩa quan trọng).
STOPWORDS_PLAIN = {
    "cua", "va", "nhe", "nha", "toi", "tui", "minh", "ban", "xin", "hoi",
    "vay", "giup", "cac", "oi", "a", "la",
}

# ---------------------------------------------------------------- cụm đồng nghĩa (đã bỏ dấu)
# Thứ tự quan trọng: quy tắc trước có thể tạo đầu vào cho quy tắc sau.
PHRASE_RULES = [
    (r"\bmon hoc\b", "hoc phan"),
    (r"\bmon\b", "hoc phan"),
    (r"\b(huy|bo|xoa) hoc phan\b", "rut hoc phan"),
    (r"\b(tien hoc|tien hoc phi)\b", "hoc phi"),
    (r"\b(dong|nop|thanh toan)( tien)? hoc phi\b", "nop hoc phi"),
    (r"\b(dong|nop) tien\b", "nop hoc phi"),
    (r"\b(hoc ky|ky|hoc|mua) he\b", "hoc ky he"),
    (r"\b(hoc ky|ky) phu\b", "hoc ky he"),
    (r"\b(tam dung hoc|nghi hoc tam thoi|tam nghi hoc|hoan hoc)\b", "bao luu"),
    (r"\b(cham lai|xem lai bai thi|kiem tra lai diem|xin xem lai diem|chap diem|khieu nai diem)\b", "phuc khao"),
    (r"\b(truot|rot|hong) hoc phan\b", "hoc phan khong dat diem f"),
    (r"\bra truong\b", "tot nghiep"),
    (r"\b(doi nganh|chuyen khoa|doi chuyen nganh)\b", "chuyen nganh"),
    (r"\b(tre han|qua han|cham)\b", "tre"),
    (r"(?<!ky )\bhe\b(?! thong)", "hoc ky he"),
    (r"\bdiem trung binh( tich luy)?\b", "diem trung binh tich luy"),
    (r"\bdiem trung binh tich luy( tich luy)+\b", "diem trung binh tich luy"),
    (r"\b(cam thi|khong duoc thi)\b", "cam thi"),
    (r"\b(copy|quay cop|chep bai)\b", "gian lan"),
    (r"\bthoi khoa bieu\b", "lich hoc"),
]
_COMPILED_RULES = [(re.compile(p), r) for p, r in PHRASE_RULES]

_TOKEN_RE = re.compile(r"\w+", re.UNICODE)


def strip_accents(text: str) -> str:
    """Bỏ dấu tiếng Việt: 'Đăng ký' -> 'Dang ky'."""
    text = unicodedata.normalize("NFD", text)
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    return text.replace("đ", "d").replace("Đ", "D")


def _tokenize(text: str) -> List[str]:
    return _TOKEN_RE.findall(text)


def preprocess(text: str) -> str:
    """Chuẩn hóa một câu: trả về chuỗi không dấu, đã mở rộng viết tắt, bỏ từ dừng, gộp từ đồng nghĩa."""
    if not text:
        return ""
    text = unicodedata.normalize("NFC", str(text)).lower()
    # "muộn" (late) và "muốn" (want) trùng nhau khi bỏ dấu -> đổi "muộn" thành "trễ" trước
    text = re.sub(r"\bmuộn\b", "trễ", text)
    tokens = _tokenize(text)

    expanded: List[str] = []
    for tok in tokens:
        if tok in ABBREVIATIONS:
            expanded.extend(_tokenize(ABBREVIATIONS[tok]))
        else:
            expanded.append(tok)

    kept = [t for t in expanded if t not in STOPWORDS_ACCENTED and t not in STOPWORDS_PLAIN]
    plain = strip_accents(" ".join(kept))

    for pattern, repl in _COMPILED_RULES:
        plain = pattern.sub(repl, plain)

    # bỏ từ lặp liên tiếp do thay thế (vd: "hoc phan hoc phan")
    out: List[str] = []
    for tok in plain.split():
        if not out or out[-1] != tok:
            out.append(tok)
    return " ".join(out)


def tokens_of(text: str) -> List[str]:
    return preprocess(text).split()
