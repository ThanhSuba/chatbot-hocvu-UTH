"""So khớp ngữ nghĩa SBERT.
Tích hợp từ phần `so khop ngu nghia + danh gia` do nhóm cung cấp.
Model mặc định: paraphrase-multilingual-MiniLM-L12-v2.
Model chỉ được tải khi chọn Semantic/Hybrid để TF-IDF/Fuzzy vẫn chạy nhẹ.
"""
from __future__ import annotations
import numpy as np

MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

class SemanticUnavailable(RuntimeError):
    """SBERT chưa thể nạp trong môi trường hiện tại."""


class SemanticEngine:
    def __init__(self, documents, model_name=MODEL_NAME):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise SemanticUnavailable(
                "Chưa nạp được SBERT. Hãy cài requirements-semantic.txt trong môi trường đang chạy Streamlit."
            ) from e
        try:
            self.model = SentenceTransformer(model_name)
        except OSError as e:
            raise SemanticUnavailable(
                "Không tải được mô hình SBERT. Hãy kiểm tra kết nối tới Hugging Face và thử lại."
            ) from e
        self.documents = list(documents)
        self.embeddings = self.model.encode(self.documents, normalize_embeddings=True, show_progress_bar=False)

    def scores(self, query: str) -> np.ndarray:
        q = self.model.encode([query], normalize_embeddings=True, show_progress_bar=False)[0]
        return np.asarray(self.embeddings @ q, dtype=float)
