"""Cấu hình tập trung của chatbot. Chỉnh ngưỡng/trọng số ở đây, không sửa trong code."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# ---- Đường dẫn ----
FAQ_PATH = BASE_DIR / "data" / "faq.json"
TOPICS_PATH = BASE_DIR / "data" / "topics.json"
TEST_SET_PATH = BASE_DIR / "data" / "test_set.json"
UNANSWERED_LOG_PATH = BASE_DIR / "logs" / "unanswered.csv"
REPORT_DIR = BASE_DIR / "reports"

# ---- Trọng số điểm tương đồng (tổng = 1) ----
W_TFIDF_WORD = 0.40   # TF-IDF theo từ (1-2 từ)
W_TFIDF_CHAR = 0.25   # TF-IDF theo ký tự (chịu lỗi chính tả)
W_FUZZY = 0.35        # rapidfuzz token_set/token_sort

# ---- Ngưỡng quyết định ----
SEMANTIC_ANSWER_THRESHOLD = 0.60
ANSWER_THRESHOLD = 0.55     # >= ngưỡng này: trả lời trực tiếp
CLARIFY_THRESHOLD = 0.40    # trong [CLARIFY, ANSWER): hỏi lại, gợi ý các câu gần nhất; dưới mức này: từ chối + ghi log
SUGGEST_THRESHOLD = 0.30    # câu gợi ý "bạn có thể quan tâm" phải đạt tối thiểu điểm này
SUGGEST_MARGIN = 0.12       # chỉ gợi ý câu có điểm cách câu top-1 không quá mức này
MAX_SUGGESTIONS = 3
AMBIGUITY_MARGIN = 0.03     # top-1 và top-2 sát nhau hơn mức này (và điểm chưa quá cao) -> hỏi lại
AMBIGUITY_MAX_SCORE = 0.75

# ---- Hội thoại đa lượt ----
TOPIC_BOOST = 0.30          # khuếch đại điểm các mục cùng chủ đề lượt trước khi gặp câu nối tiếp
# Thực thể xuyên chủ đề: nếu lượt trước nhắc tới, câu nối tiếp ngắn được hiểu là vẫn nói về nó
# (vd: "Học kỳ hè có đăng ký được không?" -> "Còn học phí thì sao?" = học phí của kỳ hè)
ENTITY_PHRASES = ["học kỳ hè"]
FOLLOWUP_MAX_TOKENS = 3     # câu hỏi ngắn hơn hoặc bằng số từ này được coi là câu hỏi nối tiếp
MAX_HISTORY = 20            # số lượt lưu trong một phiên

