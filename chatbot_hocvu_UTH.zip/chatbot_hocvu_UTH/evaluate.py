"""Đánh giá chatbot trên bộ test (data/test_set.json).

Cách dùng:
    python evaluate.py                    # đánh giá toàn bộ, in bảng kết quả
    python evaluate.py --split test       # chỉ tập test (tập dev dùng để chỉnh ngưỡng)
    python evaluate.py --sweep            # quét ngưỡng trả lời trên tập dev
    python evaluate.py --report           # ghi thêm reports/evaluation.md
    python evaluate.py --errors           # in các câu trả lời sai

Các chỉ số:
  top-1 / top-3        : mục đúng nằm đầu / trong 3 mục đầu (không xét ngưỡng)
  đúng                 : bot trả lời và đúng mục
  trả lời sai          : bot trả lời nhưng sai mục (nguy hiểm nhất)
  hỏi lại/từ chối      : bot không dám trả lời câu thuộc phạm vi
  chặn ngoài phạm vi   : câu ngoài phạm vi không bị trả lời bừa
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

import config
from chatbot.dialogue import ANSWERED, CLARIFY, FALLBACK, SMALLTALK, Chatbot
from chatbot.logger import UnansweredLogger
from chatbot.matcher import FAQMatcher


def load_test(split: str):
    with open(config.TEST_SET_PATH, encoding="utf-8") as f:
        data = json.load(f)
    single = [s for s in data["single"] if split == "all" or s["split"] == split]
    return single, data["dialogues"]


def make_bot(matcher: FAQMatcher) -> Chatbot:
    tmp = Path(tempfile.mkdtemp()) / "eval_log.csv"   # không làm bẩn log thật
    return Chatbot(matcher=matcher, logger=UnansweredLogger(tmp))


# ------------------------------------------------------------------ baseline: so khớp từ khóa thô
def keyword_baseline(matcher: FAQMatcher, query: str):
    """Baseline: lowercase + tách từ + Jaccard với câu hỏi mẫu, KHÔNG bỏ dấu/viết tắt/fuzzy."""
    q = set(re.findall(r"\w+", query.lower()))
    best_id, best = None, 0.0
    for faq in matcher.faqs:
        for text in [faq["question"], *faq.get("variants", [])]:
            d = set(re.findall(r"\w+", text.lower()))
            j = len(q & d) / len(q | d) if q | d else 0.0
            if j > best:
                best_id, best = faq["id"], j
    return best_id, best


# ------------------------------------------------------------------ chạy đánh giá câu đơn
def eval_single(bot: Chatbot, matcher: FAQMatcher, items: List[dict]) -> List[dict]:
    rows = []
    for it in items:
        ranked = matcher.search(it["q"], top_k=3)
        ids = [m.faq_id for m in ranked]
        resp = bot.ask(bot.new_session(), it["q"])
        base_id, base_score = keyword_baseline(matcher, it["q"])
        rows.append({**it, "top3": ids, "status": resp.status, "pred": resp.faq_id,
                     "score": ranked[0].score if ranked else 0.0,
                     "base_id": base_id, "base_score": base_score})
    return rows


def summarize(rows: List[dict]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, Dict[str, float]] = {}
    groups = defaultdict(list)
    for r in rows:
        groups["TẤT CẢ trong phạm vi" if r["expected"] else "ngoai"].append(r)
        groups[r["type"]].append(r)
    for name, rs in groups.items():
        n = len(rs)
        if n == 0:
            continue
        if name in ("ngoai", "ngoai_pham_vi"):
            out[name] = {"n": n, "chan": sum(r["status"] != ANSWERED for r in rs) / n,
                         "base_chan": sum(r["base_score"] < 0.35 for r in rs) / n}
            continue
        out[name] = {
            "n": n,
            "top1": sum(r["top3"][:1] == [r["expected"]] for r in rs) / n,
            "top3": sum(r["expected"] in r["top3"] for r in rs) / n,
            "dung": sum(r["status"] == ANSWERED and r["pred"] == r["expected"] for r in rs) / n,
            "sai": sum(r["status"] == ANSWERED and r["pred"] != r["expected"] for r in rs) / n,
            "hoi_lai": sum(r["status"] != ANSWERED for r in rs) / n,
            "base_top1": sum(r["base_id"] == r["expected"] for r in rs) / n,
        }
    return out


# ------------------------------------------------------------------ đánh giá hội thoại
def eval_dialogues(bot: Chatbot, dialogues: List[dict]):
    ok_ctx = ok_noctx = total = 0
    details = []
    for d in dialogues:
        session = bot.new_session()
        for turn in d["turns"]:
            total += 1
            exp = turn["expected"]
            r1 = bot.ask(session, turn["q"])                       # có ngữ cảnh
            r2 = bot.ask(bot.new_session(), turn["q"])             # không ngữ cảnh (phiên mới)

            def correct(r):
                return r.status == SMALLTALK if exp == "SMALLTALK" else (r.status == ANSWERED and r.faq_id == exp)
            ok_ctx += correct(r1)
            ok_noctx += correct(r2)
            details.append((d["name"], turn["q"], exp, r1.faq_id or r1.status, r1.used_context,
                            correct(r1), r2.faq_id or r2.status, correct(r2)))
    return ok_ctx, ok_noctx, total, details


# ------------------------------------------------------------------ quét ngưỡng
def sweep(matcher: FAQMatcher, items: List[dict]):
    bot = make_bot(matcher)
    inscope = [i for i in items if i["expected"]]
    oos = [i for i in items if not i["expected"]]
    if not inscope:
        print("Tập dev chưa có câu hỏi kèm nhãn để quét ngưỡng.")
        return
    print(f"\nQuét ANSWER_THRESHOLD trên {len(items)} câu (dev): {len(inscope)} trong phạm vi, {len(oos)} ngoài phạm vi")
    print(f"{'ngưỡng':>7} {'đúng':>7} {'trả lời sai':>12} {'hỏi lại':>9} {'ngoài PV bị trả lời':>20}")
    best = None
    for thr in [x / 100 for x in range(40, 86, 5)]:
        bot.answer_threshold = thr
        rs = [bot.ask(bot.new_session(), i["q"]) for i in inscope]
        dung = sum(r.status == ANSWERED and r.faq_id == i["expected"] for r, i in zip(rs, inscope)) / len(inscope)
        sai = sum(r.status == ANSWERED and r.faq_id != i["expected"] for r, i in zip(rs, inscope)) / len(inscope)
        lai = 1 - dung - sai
        bad = sum(bot.ask(bot.new_session(), i["q"]).status == ANSWERED for i in oos) / max(len(oos), 1)
        util = dung - 1.5 * sai - 1.5 * bad
        print(f"{thr:>7.2f} {dung:>7.1%} {sai:>12.1%} {lai:>9.1%} {bad:>20.1%}")
        if best is None or util > best[0]:
            best = (util, thr)
    print(f"\nNgưỡng tốt nhất theo tiêu chí (đúng - 1.5*sai - 1.5*ngoài PV bị trả lời): {best[1]:.2f}")


def pct(x: float) -> str:
    return f"{x:.1%}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["dev", "test", "all"], default="all")
    ap.add_argument("--sweep", action="store_true", help="quét ngưỡng trên tập dev")
    ap.add_argument("--report", action="store_true", help="ghi reports/evaluation.md")
    ap.add_argument("--errors", action="store_true", help="in các câu trả lời sai/không trả lời")
    args = ap.parse_args()

    matcher = FAQMatcher()
    if args.sweep:
        sweep(matcher, load_test("dev")[0])
        return 0

    bot = make_bot(matcher)
    single, dialogues = load_test(args.split)
    if not single:
        print(f"Tập {args.split} chưa có câu hỏi đơn lượt để đánh giá.")
        return 0
    rows = eval_single(bot, matcher, single)
    summ = summarize(rows)

    lines = [f"# Báo cáo đánh giá chatbot học vụ (tập: {args.split})", "",
             f"- Số mục FAQ: {len(matcher.faqs)}; số cách hỏi đã lập chỉ mục: {len(matcher._doc_raw)}",
             f"- Ngưỡng trả lời: {bot.answer_threshold}; ngưỡng hỏi lại: {bot.clarify_threshold}",
             f"- Số câu test: {len(rows)} (trong phạm vi: {sum(1 for r in rows if r['expected'])}, "
             f"ngoài phạm vi: {sum(1 for r in rows if not r['expected'])})", "",
             "## 1. Câu hỏi thuộc phạm vi FAQ", "",
             "| Nhóm | Số câu | Top-1 | Top-3 | Trả lời đúng | Trả lời sai | Hỏi lại/từ chối | Baseline từ khóa (top-1) |",
             "|---|---|---|---|---|---|---|---|"]
    names = {"TẤT CẢ trong phạm vi": "**Tất cả**", "dien_dat_khac": "Diễn đạt khác (có dấu)",
             "khong_dau_viet_tat": "Không dấu / viết tắt / teencode"}
    for key in ["TẤT CẢ trong phạm vi", "dien_dat_khac", "khong_dau_viet_tat"]:
        s = summ.get(key)
        if s:
            lines.append(f"| {names[key]} | {int(s['n'])} | {pct(s['top1'])} | {pct(s['top3'])} | {pct(s['dung'])} | "
                         f"{pct(s['sai'])} | {pct(s['hoi_lai'])} | {pct(s['base_top1'])} |")
    s = summ.get("ngoai_pham_vi")
    lines += ["", "## 2. Câu hỏi ngoài phạm vi", ""]
    if s:
        lines += [f"- Số câu: {int(s['n'])}",
                  f"- **Chatbot không trả lời bừa: {pct(s['chan'])}** (baseline từ khóa: {pct(s['base_chan'])})"]

    ok_ctx, ok_noctx, total, details = eval_dialogues(bot, dialogues)
    lines += ["", "## 3. Hội thoại nhiều lượt", "",
              f"- {len(dialogues)} đoạn hội thoại, {total} lượt hỏi",
              f"- Đúng khi **có** ngữ cảnh: {ok_ctx}/{total} ({pct(ok_ctx / total)})",
              f"- Đúng khi **không** dùng ngữ cảnh (mỗi câu một phiên mới): {ok_noctx}/{total} ({pct(ok_noctx / total)})", ""]
    lines += ["| Hội thoại | Câu hỏi | Mong đợi | Có ngữ cảnh | Dùng ngữ cảnh | Không ngữ cảnh |", "|---|---|---|---|---|---|"]
    for name, q, exp, got1, used, c1, got2, c2 in details:
        lines.append(f"| {name} | {q} | {exp} | {'✅' if c1 else '❌'} {got1} | {'có' if used else ''} | {'✅' if c2 else '❌'} {got2} |")

    with (config.TEST_SET_PATH.parent / "test_data_nhom.json").open(encoding="utf-8") as f:
        group_cases = json.load(f)
    expected_status = {"FALLBACK_LOG": FALLBACK, "CLARIFY": CLARIFY, "GREETING_FALLBACK": SMALLTALK}
    lines += ["", "## 4. Hành vi hội thoại theo tình huống của nhóm", "",
              "| Mã | Mong đợi | Kết quả |", "|---|---|---|"]
    for case in group_cases:
        kind = case["expected_faq_id"]
        if kind not in expected_status:
            continue
        session = bot.new_session()
        response = bot.ask(session, case["user_input"])
        correct = response.status == expected_status[kind]
        if kind == "FALLBACK_LOG":
            logged = any(row["session_id"] == session.id for row in bot.logger.read())
            correct = correct and logged
            actual = f"{response.status}, " + ("đã ghi log" if logged else "chưa ghi log")
        else:
            actual = response.status
        lines.append(f"| {case['test_id']} | {kind} | {'✅' if correct else '❌'} {actual} |")

    report = "\n".join(lines)
    print(report)

    if args.errors:
        print("\n## Các câu chưa đúng")
        for r in rows:
            if r["expected"] and not (r["status"] == ANSWERED and r["pred"] == r["expected"]):
                print(f"- [{r['type']}] {r['q']!r}: mong đợi {r['expected']}, top3={r['top3']}, "
                      f"bot={r['status']}:{r['pred']} (điểm {r['score']:.2f})")
            if not r["expected"] and r["status"] == ANSWERED:
                print(f"- [ngoài phạm vi bị trả lời] {r['q']!r} -> {r['pred']} (điểm {r['score']:.2f})")

    if args.report:
        config.REPORT_DIR.mkdir(exist_ok=True)
        out = config.REPORT_DIR / "evaluation.md"
        out.write_text(report + "\n", encoding="utf-8")
        print(f"\nĐã ghi {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
