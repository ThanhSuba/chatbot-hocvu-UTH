"""So sánh các phương pháp trên cùng tập câu hỏi tiếng Việt."""
import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from chatbot.dialogue import ANSWERED, Chatbot
from chatbot.logger import UnansweredLogger
from chatbot.matcher import FAQMatcher
import config


def ratio(numerator, denominator):
    return numerator / denominator if denominator else 0.0


def run(method, items, log_path):
    matcher = FAQMatcher(method=method)
    bot = Chatbot(matcher=matcher, logger=UnansweredLogger(log_path))
    positives = sum(bool(item["expected"]) for item in items)
    top1 = answered = correct = blocked = 0
    for item in items:
        query, expected = item["q"], item["expected"]
        ranked = matcher.search(query, top_k=1)
        top1 += bool(expected and ranked and ranked[0].faq_id == expected)
        response = bot.ask(bot.new_session(), query)
        accepted = response.status == ANSWERED
        answered += accepted
        correct += bool(accepted and expected and response.faq_id == expected)
        blocked += not accepted and not expected

    precision = ratio(correct, answered)
    recall = ratio(correct, positives)
    return (
        ratio(top1, positives),
        ratio(correct + blocked, len(items)),
        precision,
        recall,
        ratio(2 * precision * recall, precision + recall),
        ratio(blocked, len(items) - positives),
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--semantic", action="store_true")
    args = parser.parse_args()
    methods = ["tfidf", "fuzzy", "hybrid_tfidf_fuzzy"]
    if args.semantic:
        methods.extend(["semantic", "hybrid_semantic"])
    data = json.loads(config.TEST_SET_PATH.read_text(encoding="utf-8"))
    items = [item for item in data["single"] if item.get("split", "test") == "test"]
    print(f"Số câu test: {len(items)}")
    print("| Phương pháp | Top-1 | Accuracy | Precision | Recall | F1 | Chặn ngoài phạm vi |")
    print("|---|---:|---:|---:|---:|---:|---:|")
    with TemporaryDirectory() as directory:
        for method in methods:
            scores = run(method, items, Path(directory) / f"{method}.csv")
            print(f"| {method} | " + " | ".join(f"{score:.1%}" for score in scores) + " |")


if __name__ == "__main__":
    main()
