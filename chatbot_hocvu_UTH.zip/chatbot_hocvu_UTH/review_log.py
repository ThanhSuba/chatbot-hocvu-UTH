"""Xem các câu hỏi bot không trả lời được để bổ sung FAQ:  python review_log.py [--top 15]"""
import argparse
import sys

from chatbot.logger import UnansweredLogger


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=15)
    args = ap.parse_args()

    logger = UnansweredLogger()
    rows = logger.read()
    if not rows:
        print("Chưa có câu hỏi nào bị ghi log.")
        return 0
    print(f"Tổng số lần bot không trả lời được: {len(rows)}  (file: {logger.path})\n")
    print(f"Top {args.top} câu hỏi lặp lại nhiều nhất (nên bổ sung vào data/faq.json):")
    for q, n, status in logger.summarize(args.top):
        print(f"  {n:>3}x  [{status}]  {q}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
