"""Chạy:  python -m unittest discover -s tests -v"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config
from chatbot.dialogue import ANSWERED, CLARIFY, FALLBACK, SMALLTALK, Chatbot  # noqa: E402
from chatbot.logger import UnansweredLogger  # noqa: E402
from chatbot.matcher import FAQMatcher  # noqa: E402
from chatbot.preprocess import preprocess, strip_accents  # noqa: E402

FIXTURES = Path(__file__).with_name("fixtures")
MATCHER = FAQMatcher(FIXTURES / "faq.json")


def make_bot():
    log_path = Path(tempfile.mkdtemp()) / "u.csv"
    with patch.object(config, "TOPICS_PATH", FIXTURES / "topics.json"):
        bot = Chatbot(matcher=MATCHER, logger=UnansweredLogger(log_path))
    return bot, log_path


class TestPreprocess(unittest.TestCase):
    def test_strip_accents(self):
        self.assertEqual(strip_accents("Đăng ký học phần"), "Dang ky hoc phan")

    def test_accented_and_plain_equal(self):
        self.assertEqual(preprocess("Học phí bao nhiêu?"), preprocess("hoc phi bao nhieu"))

    def test_abbreviations(self):
        self.assertIn("dang ky hoc phan", preprocess("dkhp khi nào"))
        self.assertIn("khong duoc", preprocess("ko dc"))

    def test_synonym_normalisation(self):
        self.assertEqual(preprocess("đóng tiền học"), preprocess("nộp học phí"))

    def test_late_vs_want(self):
        self.assertNotEqual(preprocess("đăng ký muộn"), preprocess("đăng ký muốn"))

    def test_exam_not_removed_without_accent(self):
        self.assertIn("thi", preprocess("lich thi").split())

    def test_empty(self):
        self.assertEqual(preprocess(""), "")
        self.assertEqual(preprocess(None), "")


class TestMatcher(unittest.TestCase):
    def test_exact_question(self):
        self.assertEqual(MATCHER.best("Hạn nộp học phí là khi nào?").faq_id, "hp_02")

    def test_paraphrase(self):
        self.assertEqual(MATCHER.best("Quên đóng tiền học thì sao").faq_id, "hp_04")

    def test_no_accent_abbrev(self):
        self.assertEqual(MATCHER.best("hoc phi 1 tin chi bn").faq_id, "hp_01")

    def test_typo(self):
        self.assertEqual(MATCHER.best("lịch thi xem ở dâu").faq_id, "lt_01")

    def test_word_order(self):
        self.assertEqual(MATCHER.best("điểm thi khi nào có").faq_id, "diem_04")

    def test_out_of_scope_low_score(self):
        self.assertLess(MATCHER.best("cách nấu phở bò").score, 0.55)

    def test_generic_words_only_not_enough(self):
        self.assertLess(MATCHER.best("Bạn bao nhiêu tuổi").score, 0.55)

    def test_typo_correction_long_words(self):
        self.assertEqual(MATCHER.best("thu tuc phuc khao bai thii").faq_id, "diem_06")

    def test_faq_data_valid(self):
        faqs = FAQMatcher().faqs
        ids = [f["id"] for f in faqs]
        self.assertEqual(len(ids), len(set(ids)))
        for f in faqs:
            self.assertTrue(f["question"] and f["answer"] and f["topic"])

    def test_imported_variant_questions_are_present(self):
        source_path = config.BASE_DIR / "data" / "FAQ_bien_the_quy_che_dao_tao_UTH_nguon.json"
        source_questions = json.loads(source_path.read_text(encoding="utf-8"))
        searchable_questions = {
            (faq["topic"], question.casefold().strip())
            for faq in FAQMatcher().faqs
            for question in [faq["question"], *faq.get("variants", [])]
        }
        missing = [
            item["question"]
            for item in source_questions
            if (item["topic"], item["question"].casefold().strip()) not in searchable_questions
        ]
        self.assertEqual(len(source_questions), 210)
        self.assertEqual(missing, [])

    def test_imported_variants_match_expected_faq(self):
        matcher = FAQMatcher()
        cases = {
            "Học theo tín chỉ nghĩa là như thế nào?": "UTH_QC_001",
            "Điểm chữ A, B, C được đổi sang hệ 4 ra sao?": "UTH_QC_038",
            "Không qua môn bắt buộc thì phải đăng ký học lại thế nào?": "UTH_QC_040",
        }
        for question, expected_id in cases.items():
            self.assertEqual(matcher.best(question).faq_id, expected_id)


class TestDialogue(unittest.TestCase):
    def test_uth_topics_are_displayed_in_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            logger = UnansweredLogger(Path(directory) / "unanswered.csv")
            bot = Chatbot(logger=logger)
            response = bot.ask(bot.new_session(), "Cách nấu phở bò ngon")
            self.assertEqual(response.status, FALLBACK)
            self.assertIn("học phí", response.text)
            self.assertEqual(logger.read()[0]["trang_thai"], "ngoai_pham_vi")

    def test_answer(self):
        bot, _ = make_bot()
        r = bot.ask(bot.new_session(), "Học phí mỗi tín chỉ bao nhiêu?")
        self.assertEqual((r.status, r.faq_id), (ANSWERED, "hp_01"))

    def test_multi_turn_context(self):
        bot, _ = make_bot()
        s = bot.new_session()
        bot.ask(s, "Học phí mỗi tín chỉ bao nhiêu?")
        r = bot.ask(s, "Còn kỳ hè thì sao?")
        self.assertEqual((r.status, r.faq_id, r.used_context), (ANSWERED, "hp_05", True))
        # cùng câu hỏi nhưng không có ngữ cảnh -> hiểu khác (học kỳ hè nói chung)
        r2 = bot.ask(bot.new_session(), "Còn kỳ hè thì sao?")
        self.assertNotEqual(r2.faq_id, "hp_05")

    def test_entity_carry_over(self):
        bot, _ = make_bot()
        s = bot.new_session()
        bot.ask(s, "Học kỳ hè có đăng ký được không")
        r = bot.ask(s, "Còn học phí thì sao?")
        self.assertEqual(r.faq_id, "hp_05")

    def test_out_of_scope_is_logged(self):
        bot, path = make_bot()
        r = bot.ask(bot.new_session(), "Cách nấu phở bò ngon")
        self.assertEqual(r.status, FALLBACK)
        rows = UnansweredLogger(path).read()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["trang_thai"], "ngoai_pham_vi")
        self.assertEqual(rows[0]["cau_hoi"], "Cách nấu phở bò ngon")

    def test_answered_not_logged(self):
        bot, path = make_bot()
        bot.ask(bot.new_session(), "Xem lịch thi ở đâu?")
        self.assertEqual(len(UnansweredLogger(path).read()), 0)

    def test_training_examples_from_feedback_log(self):
        bot = Chatbot()
        cases = {
            "Học lại để cải thiện điểm có được không": "UTH_QC_043",
            "Có bao nhiêu thang đo điểm": "UTH_QC_038",
            "Số buổi tối đa được phép nghỉ": "FAQ_LT_04",
            "Mỗi học kỳ sinh viên được đăng ký tối đa bao nhiêu tín chỉ": "UTH_QC_014",
            "Cảnh báo học tập": "UTH_QC_046",
            "Thôi học là gì": "UTH_QC_056",
        }
        for question, expected_id in cases.items():
            response = bot.ask(bot.new_session(), question)
            self.assertEqual((response.status, response.faq_id), (ANSWERED, expected_id))

    def test_short_learning_requests_get_useful_follow_up(self):
        bot = Chatbot()
        overview = bot.ask(bot.new_session(), "tổng quan quy chế đào tạo")
        self.assertEqual(overview.status, ANSWERED)
        session = bot.new_session()
        answer = bot.ask(session, "học lại")
        self.assertEqual(answer.status, CLARIFY)
        self.assertEqual(len(session.pending), 3)
        self.assertEqual(bot.ask(session, "3").faq_id, "UTH_QC_043")

    def test_recent_feedback_examples_have_specific_answers(self):
        bot = Chatbot()
        cases = {
            "làm thế nào để đăng ký lại học phần đã bị rớt trước đó": "UTH_QC_040",
            "điểm chuyên cần": "UTH_QC_022",
            "làm thế nào để được cộng điểm chuyên cần": "UTH_QC_022",
            "tại sao lại bị thôi học": "UTH_QC_051",
        }
        for question, expected_id in cases.items():
            response = bot.ask(bot.new_session(), question)
            self.assertEqual((response.status, response.faq_id), (ANSWERED, expected_id))

    def test_tuition_by_program_and_cohort(self):
        bot = Chatbot()
        standard = bot.ask(bot.new_session(), "Học phí 1 tín chỉ hệ chuẩn là bao nhiêu?")
        self.assertEqual(standard.status, ANSWERED)
        self.assertIn("515.000", standard.text)
        advanced = bot.ask(bot.new_session(), "Học phí 1 tín chỉ chương trình tiên tiến là bao nhiêu?")
        self.assertIn("1.120.000", advanced.text)
        english = bot.ask(bot.new_session(), "Học phí chương trình hoàn toàn bằng tiếng Anh?")
        self.assertIn("1.500.000", english.text)

    def test_clarify_then_choose_number(self):
        bot, _ = make_bot()
        s = bot.new_session()
        r = bot.ask(s, "học phí")                       # câu quá mơ hồ -> hỏi lại
        self.assertEqual(r.status, CLARIFY)
        self.assertTrue(s.pending)
        expected_id = s.pending[1].faq_id
        r2 = bot.ask(s, "2")
        self.assertEqual((r2.status, r2.faq_id), (ANSWERED, expected_id))

    def test_clarify_then_reject_logs(self):
        bot, path = make_bot()
        s = bot.new_session()
        bot.ask(s, "học phí")
        bot.ask(s, "không phải")
        statuses = [r["trang_thai"] for r in UnansweredLogger(path).read()]
        self.assertIn("tu_choi_goi_y", statuses)

    def test_smalltalk(self):
        bot, path = make_bot()
        s = bot.new_session()
        self.assertEqual(bot.ask(s, "Xin chào").status, SMALLTALK)
        self.assertEqual(bot.ask(s, "cảm ơn bạn").status, SMALLTALK)
        self.assertEqual(len(UnansweredLogger(path).read()), 0)

    def test_greeting_plus_question_answers_question(self):
        bot, _ = make_bot()
        r = bot.ask(bot.new_session(), "Xin chào, cho mình hỏi hạn nộp học phí là khi nào?")
        self.assertEqual((r.status, r.faq_id), (ANSWERED, "hp_02"))

    def test_empty_and_long_input(self):
        bot, path = make_bot()
        s = bot.new_session()
        self.assertEqual(bot.ask(s, "   ").status, "empty")
        r = bot.ask(s, "học phí " * 2000)               # không được lỗi
        self.assertIsNotNone(r.text)
        self.assertEqual(bot.ask(s, "???").status, FALLBACK)

    def test_reset_clears_context(self):
        bot, _ = make_bot()
        s = bot.new_session()
        bot.ask(s, "Học phí mỗi tín chỉ bao nhiêu?")
        s.reset()
        self.assertIsNone(s.last_topic)
        self.assertEqual(s.history, [])


class TestLogger(unittest.TestCase):
    def test_summarize_groups_duplicates(self):
        path = Path(tempfile.mkdtemp()) / "u.csv"
        lg = UnansweredLogger(path)
        for q in ["Giá vàng?", "giá vàng", "Cách nấu phở"]:
            lg.log("s1", q, q.lower().strip("?"), "ngoai_pham_vi", 0.1)
        top = lg.summarize(5)
        self.assertEqual(top[0][1], 2)


if __name__ == "__main__":
    unittest.main()
